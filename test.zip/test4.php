<?php
return [
	[
		'name' => 'Продажи',
		'tickets' => '34 шт.',
		'percent_tickets' => '2323',
		'sum' => '880 руб',
		'percent_sum' => '234'
	],
	[
		'name' => 'Продажи',
		'tickets' => '34 шт.',
		'percent_tickets' => '2323',
		'sum' => '880 руб',
		'percent_sum' => '234'
	],
	[
		'name' => 'Продажи',
		'tickets' => '34 шт.',
		'percent_tickets' => '2323',
		'sum' => '880 руб',
		'percent_sum' => '234',
		'isTotal' => true
	],
];
