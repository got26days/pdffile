<?php
return [
	0 => [
		'title' => 'План',
		'blocks' => [
			[
				'title' => null,
				'data' => [
					[
						'tickets' => '914 шт.',
						'invitation' => '34 шт.',
						'shaft' => '4 355 500 руб',
						'sale' => '880 шт.',
						'avg' => '4 765 руб'
					],
				]
			],
		]
	],
	1 => [
		'title' => 'Ценовые пояса',
		'blocks' => [
			[
				'title' => null,
				'data' => [
					[
						'zone' => '#C24383',
						'price' => 2000,
						'amount' => 55,
						'sum' => 123000,
					],
					[
						'zone' => '#C24383',
						'price' => 2000,
						'amount' => 55,
						'sum' => 123000,
					],
					[
						'zone' => '#C24383',
						'price' => 2000,
						'amount' => 55,
						'sum' => 123000,
					],
				]
			],
		]
	]
];
