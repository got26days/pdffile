<?php
return [
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
	[
		'operator' => 'Оператор',
		'number_sold' => '34 шт.',
		'sum_sold' => '2323',
		'number_return' => '880 руб',
		'sum_return' => '234'
	],
];
