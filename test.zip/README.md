# Php pdf generator

## Установка

```sh
cd pdfCode
composer install
```

## Изменение макета

Для изменения макета измените файл /templates/template.html
Очистите папку /complication_cache, для удаления кэшированного представления twig.
Откройте исполняймый файл. 

## _Разработка_
[Palagov S.]


[Palagov S.]: <https://worksholder.space/>